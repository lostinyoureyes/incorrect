DShowPlayer

Demonstrates audio/video playback using DirectShow.