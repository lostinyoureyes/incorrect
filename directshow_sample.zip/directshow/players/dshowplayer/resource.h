//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DShowPlayer.rc
//
#define IDC_MYICON                      2
#define IDD_DSHOWPLAYER_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_DSHOWPLAYER                 107
#define IDI_SMALL                       108
#define IDC_DSHOWPLAYER                 109
#define IDR_MAINFRAME                   128
#define IDB_TOOLBAR_IMAGES_NORMAL       129
#define IDB_TOOLBAR_IMAGES_DISABLED     131
#define IDB_SLIDER_THUMB				132
#define IDB_SLIDER_VOLUME				133
#define IDC_REBAR_CONTROL               400
#define IDC_BUTTON_PLAY                 401
#define IDC_BUTTON_STOP                 402
#define IDC_TOOLBAR                     403
#define IDC_BUTTON_PAUSE                404
#define IDC_SEEKBAR						405
#define IDC_BUTTON_MUTE					406
#define IDC_VOLUME						407
#define ID_FILE_OPENFILE                32771
#define IDC_STATIC                      -1

// Define image list values. 
// These are index values into the imagelist bitmaps for the tool bar.

#define ID_IMAGE_PLAY					0
#define ID_IMAGE_STOP					1
#define ID_IMAGE_PAUSE					2
#define ID_IMAGE_MUTE_OFF				3
#define ID_IMAGE_MUTE_ON 				4

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
