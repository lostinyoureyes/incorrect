//------------------------------------------------------------------------------
// File: CutScene.h
//
// Desc: DirectShow sample code - declarations for simple movie player.
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------


//
// Function prototypes
//
HRESULT PlayCutscene(LPTSTR lpszMovie, HINSTANCE hInstance);
